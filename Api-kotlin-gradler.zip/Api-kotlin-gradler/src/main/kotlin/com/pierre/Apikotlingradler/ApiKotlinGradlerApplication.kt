package com.pierre.Apikotlingradler

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class ApiKotlinGradlerApplication

fun main(args: Array<String>) {
	runApplication<ApiKotlinGradlerApplication>(*args)
}
